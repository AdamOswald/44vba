#pragma once

void convert_text(char *text, int l);
